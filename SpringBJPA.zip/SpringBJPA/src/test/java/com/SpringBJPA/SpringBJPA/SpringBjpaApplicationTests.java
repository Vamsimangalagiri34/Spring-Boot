package com.SpringBJPA.SpringBJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBjpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
