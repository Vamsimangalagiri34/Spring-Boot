package com.SpringBJPA.SpringBJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBjpaApplication.class, args);
	}

}
